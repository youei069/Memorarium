﻿const { withStore } = require('../utils/store');
const { hashPassword, verifyPassword, newId, parseCookies } = require('../utils/auth');

function register(req, res) {
  const { email, password } = req.body;

  if (!email || !password || password.length < 8) {
    return res.status(400).json({ error: 'メールアドレスと8文字以上のパスワードが必要です。' });
  }

  const result = withStore((store) => {
    const exists = store.users.some((u) => u.email.toLowerCase() === email.toLowerCase());
    if (exists) {
      return { error: 'このメールアドレスは既に登録されています。' };
    }

    const user = {
      id: newId('user'),
      email,
      passwordHash: hashPassword(password),
      createdAt: Date.now()
    };

    store.users.push(user);
    return { userId: user.id, email: user.email };
  });

  if (result.error) {
    return res.status(409).json({ error: result.error });
  }

  return res.status(201).json({ message: '登録が完了しました', user: result });
}

function login(req, res) {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'メールアドレスとパスワードを入力してください。' });
  }

  const result = withStore((store) => {
    const user = store.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return { error: 'メールアドレスまたはパスワードが正しくありません。' };
    }

    const token = newId('session');
    store.sessions.push({ token, userId: user.id, createdAt: Date.now() });
    return { token, user: { id: user.id, email: user.email } };
  });

  if (result.error) {
    return res.status(401).json({ error: result.error });
  }

  res.setHeader('Set-Cookie', `session_token=${result.token}; HttpOnly; Path=/; SameSite=Strict`);
  return res.json({ message: 'ログインしました', user: result.user });
}

function me(req, res) {
  return res.json({ user: req.user });
}

function logout(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  const token = cookies.session_token;

  if (token) {
    withStore((store) => {
      store.sessions = store.sessions.filter((s) => s.token !== token);
    });
  }

  res.setHeader('Set-Cookie', 'session_token=; HttpOnly; Path=/; SameSite=Strict; Max-Age=0');
  return res.json({ message: 'ログアウトしました' });
}

module.exports = {
  register,
  login,
  me,
  logout
};

