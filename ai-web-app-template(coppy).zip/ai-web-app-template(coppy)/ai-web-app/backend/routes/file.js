const express = require('express');
const multer = require('multer');
const path = require('path');
const controller = require('../controllers/fileController');
const authMiddleware = require('../middleware/authMiddleware');

const uploadDir = path.join(__dirname, '..', '..', 'uploads');
const upload = multer({ dest: uploadDir, limits: { fileSize: 10 * 1024 * 1024 } });

const router = express.Router();

router.post('/analyze', authMiddleware, upload.single('file'), controller.analyzeFile);

module.exports = router;
