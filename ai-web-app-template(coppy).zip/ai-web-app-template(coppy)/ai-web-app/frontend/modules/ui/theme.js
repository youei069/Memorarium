﻿export function createThemeManager({ board, i18n, saveTheme }) {
  function applyTheme(theme) {
    const mode = theme.mode || 'system';
    const custom = theme.custom || {};
    const root = document.documentElement;
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (mode === 'dark' || (mode === 'system' && prefersDark)) {
      root.setAttribute('data-theme', 'dark');
    } else {
      root.removeAttribute('data-theme');
    }

    root.style.setProperty('--accent', custom.accent || '#5b7cfa');
    root.style.setProperty('--bg', custom.bgColor || '#eef2f8');

    if (custom.bgImage) {
      board.style.backgroundImage = `url('${custom.bgImage}'), radial-gradient(var(--board-dot) 1px, transparent 1px)`;
      board.classList.add('custom-bg');
    } else {
      board.style.backgroundImage = '';
      board.classList.remove('custom-bg');
    }

    const setValue = (id, value) => {
      const el = document.getElementById(id);
      if (el && value !== undefined && value !== null) el.value = value;
    };

    setValue('themeMode', mode);
    setValue('themeAccent', custom.accent || '#5b7cfa');
    setValue('bgColor', custom.bgColor || '#eef2f8');
    setValue('bgImage', custom.bgImage || '');

    if (custom.language) {
      i18n.load(custom.language).catch(() => {});
    }
  }

  function bindThemeControls() {
    document.getElementById('themeSaveBtn')?.addEventListener('click', async () => {
      await saveTheme(false);
    });

    document.getElementById('shareThemeBtn')?.addEventListener('click', async () => {
      await saveTheme(true);
    });

    document.getElementById('bgImage')?.addEventListener('change', () => saveTheme(false));
    document.getElementById('themeMode')?.addEventListener('change', () => saveTheme(false));
    document.getElementById('themeAccent')?.addEventListener('input', () => saveTheme(false));
    document.getElementById('bgColor')?.addEventListener('input', () => saveTheme(false));
  }

  return { applyTheme, bindThemeControls };
}

