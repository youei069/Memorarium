﻿const imageModule = (() => {
  async function generate() {
    const promptEl = document.getElementById('imagePrompt');
    const resultEl = document.getElementById('imageResult');
    if (!promptEl || !resultEl) return;

    const prompt = promptEl.value.trim();
    if (!prompt) return;

    resultEl.textContent = '生成中...';
    try {
      const data = await window.authApi.api('/api/image', {
        method: 'POST',
        body: JSON.stringify({ prompt })
      });
      resultEl.innerHTML = `<p>${data.note}</p><img src="${data.imageUrl}" alt="生成画像" style="max-width:100%;border-radius:8px;"><p><a href="${data.imageUrl}" download>ダウンロード</a></p>`;
    } catch (error) {
      resultEl.textContent = error.message;
    }
  }

  return { generate };
})();

window.imageModule = imageModule;

