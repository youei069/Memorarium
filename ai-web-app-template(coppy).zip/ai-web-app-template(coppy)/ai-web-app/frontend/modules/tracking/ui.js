﻿export function bindTrackingUI({ engine, elements, i18n }) {
  const {
    toggleBtn,
    gazeBtn,
    writingBtn,
    focusEl,
    eyeEl,
    handEl,
    postureEl,
    logEl,
    zoneSizeInput
  } = elements;

  let running = false;

  function updateButtons() {
    toggleBtn.textContent = running ? i18n.t('tracking.stop') : i18n.t('tracking.start');
  }

  function focusLabel(snapshot) {
    if (snapshot.isPageTurning) return { text: i18n.t('tracking.pageTurning'), color: 'yellow' };
    if (snapshot.gazeState === 'LOOKING_AWAY') return { text: i18n.t('tracking.distracted'), color: 'red' };
    if (snapshot.writingState === 'WRITING') return { text: i18n.t('tracking.writingState'), color: 'green' };
    return { text: i18n.t('tracking.focused'), color: 'green' };
  }

  function updateUI(snapshot) {
    if (!snapshot) return;
    const focus = focusLabel(snapshot);
    focusEl.textContent = focus.text;
    focusEl.className = `status-pill ${focus.color}`;

    if (snapshot.gazeState === 'LOOKING_AWAY' || snapshot.gazeState === 'AWAY_SHORT') {
      eyeEl.textContent = i18n.t('tracking.gazeAway');
    } else if (snapshot.gazeState === 'PAGE_TURNING') {
      eyeEl.textContent = i18n.t('tracking.pageTurning');
    } else {
      eyeEl.textContent = i18n.t('tracking.gazeInside');
    }

    if (snapshot.writingState === 'WRITING') {
      handEl.textContent = i18n.t('tracking.handWriting');
    } else if (snapshot.writingState === 'HOLDING_PENCIL') {
      handEl.textContent = i18n.t('tracking.handHolding');
    } else if (snapshot.handDetected) {
      handEl.textContent = i18n.t('tracking.handDetected');
    } else {
      handEl.textContent = i18n.t('tracking.handMissing');
    }

    postureEl.textContent = `${snapshot.postureScore}`;

    if (logEl) {
      const modeLabel = snapshot.mode === 'writing' ? i18n.t('tracking.writing') : i18n.t('tracking.gaze');
      const gazeMap = {
        STUDYING: i18n.t('tracking.focused'),
        LOOKING_AWAY: i18n.t('tracking.distracted'),
        PAGE_TURNING: i18n.t('tracking.pageTurning'),
        AWAY_SHORT: i18n.t('tracking.gazeAway')
      };
      const writingMap = {
        WRITING: i18n.t('tracking.handWriting'),
        HOLDING_PENCIL: i18n.t('tracking.handHolding'),
        HAND_PRESENT: i18n.t('tracking.handDetected'),
        NONE: i18n.t('tracking.handMissing')
      };
      logEl.textContent = [
        `モード: ${modeLabel}`,
        `視線: ${gazeMap[snapshot.gazeState] || snapshot.gazeState}`,
        `筆記: ${writingMap[snapshot.writingState] || snapshot.writingState}`,
        `姿勢: ${snapshot.postureScore}`,
        `手: ${snapshot.handScore}`,
        `目: ${snapshot.eyeScore}`
      ].join('\n');
    }
  }

  toggleBtn.addEventListener('click', async () => {
    running = !running;
    updateButtons();
    if (running) {
      await engine.start();
    } else {
      engine.stop();
    }
  });

  gazeBtn.addEventListener('click', () => {
    engine.setMode('gaze');
    gazeBtn.classList.add('mode-active');
    writingBtn.classList.remove('mode-active');
  });

  writingBtn.addEventListener('click', () => {
    engine.setMode('writing');
    writingBtn.classList.add('mode-active');
    gazeBtn.classList.remove('mode-active');
  });

  zoneSizeInput?.addEventListener('input', (event) => {
    engine.setZoneSize(Number(event.target.value));
    engine.updateZoneOverlay();
  });

  engine.subscribe(updateUI);
  updateButtons();
  gazeBtn.classList.add('mode-active');
}

