﻿import { initBoard } from '../modules/ui/board.js';
import { createThemeManager } from '../modules/ui/theme.js';
import { widgetDefs, defaultLayout, widgetTemplate } from '../modules/widgets/registry.js';
import { createWidgetManager } from '../modules/widgets/manager.js';
import { createTrackingEngine } from '../modules/tracking/engine.js';
import { bindTrackingUI } from '../modules/tracking/ui.js';

const dashboardModule = (() => {
  const state = {
    tasks: [],
    notes: [],
    theme: { mode: 'system', custom: {} },
    layout: { widgets: { layoutMap: {}, widgetData: {} } },
    widgetData: {
      notifications: [],
      progressWeekly: [6, 7, 8, 9, 7, 4, 5],
      progressTotal: '12時間20分'
    }
  };

  let saveTimer = null;
  let widgetManager = null;
  let trackingEngine = null;

  function normalizeLayout(raw) {
    const layoutMap = {};
    const widgetData = raw?.widgets?.widgetData || {};

    if (raw?.widgets?.layoutMap) {
      return {
        layoutMap: { ...defaultLayout, ...raw.widgets.layoutMap },
        widgetData: { ...state.widgetData, ...widgetData }
      };
    }

    Object.keys(defaultLayout).forEach((id, index) => {
      layoutMap[id] = { ...defaultLayout[id], y: defaultLayout[id].y + index * 4 };
    });

    return {
      layoutMap,
      widgetData: { ...state.widgetData, ...widgetData }
    };
  }

  function queueSaveLayout() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveLayout, 500);
  }

  async function saveLayout() {
    state.layout.widgetData = state.widgetData;
    await window.authApi.api('/api/dashboard/layout', {
      method: 'POST',
      body: JSON.stringify({ widgets: state.layout })
    });
  }

  async function saveTheme(shared) {
    const mode = document.getElementById('themeMode').value;
    const custom = {
      accent: document.getElementById('themeAccent').value,
      bgColor: document.getElementById('bgColor').value,
      bgImage: document.getElementById('bgImage').value.trim(),
      language: 'ja'
    };

    await window.authApi.api('/api/dashboard/theme', {
      method: 'POST',
      body: JSON.stringify({ mode, custom, shared: Boolean(shared), name: `theme-${Date.now()}` })
    });
    themeManager?.applyTheme({ mode, custom });
  }

  function renderNotes() {
    const noteList = document.getElementById('noteList');
    if (!noteList) return;
    noteList.innerHTML = '';
    state.notes.forEach((note) => {
      const li = document.createElement('li');
      li.innerHTML = `<span>${note.text}</span>`;
      const del = document.createElement('button');
      del.className = 'ghost';
      del.textContent = window.i18n.t('dashboard.remove');
      del.onclick = async () => {
        await window.authApi.api(`/api/dashboard/notes/${note.id}`, { method: 'DELETE' });
        state.notes = state.notes.filter((n) => n.id !== note.id);
        renderNotes();
      };
      li.appendChild(del);
      noteList.appendChild(li);
    });
  }

  function renderTasks() {
    const taskList = document.getElementById('taskList');
    if (!taskList) return;
    taskList.innerHTML = '';
    state.tasks.forEach((task) => {
      const li = document.createElement('li');
      const priorityLabel = task.priority === 'high' ? '高' : task.priority === 'low' ? '低' : '中';
      li.innerHTML = `<span>${task.done ? '?' : '○'} ${task.title} (${priorityLabel})</span>`;
      const wrap = document.createElement('div');

      const doneBtn = document.createElement('button');
      doneBtn.textContent = task.done ? '未完了' : '完了';
      doneBtn.onclick = async () => {
        const result = await window.authApi.api('/api/dashboard/tasks', {
          method: 'PATCH',
          body: JSON.stringify({ id: task.id, done: !task.done })
        });
        task.done = result.task.done;
        renderTasks();
      };

      const delBtn = document.createElement('button');
      delBtn.className = 'ghost';
      delBtn.textContent = window.i18n.t('dashboard.remove');
      delBtn.onclick = async () => {
        await window.authApi.api(`/api/dashboard/tasks/${task.id}`, { method: 'DELETE' });
        state.tasks = state.tasks.filter((t) => t.id !== task.id);
        renderTasks();
      };

      wrap.append(doneBtn, delBtn);
      li.appendChild(wrap);
      taskList.appendChild(li);
    });
  }

  function renderProgress() {
    const chart = document.getElementById('progressChart');
    const total = document.getElementById('progressTotal');
    if (!chart) return;
    chart.innerHTML = '';
    const values = state.widgetData.progressWeekly || [5, 6, 7, 8, 6, 4, 5];
    const max = Math.max(...values, 10);
    values.forEach((value) => {
      const bar = document.createElement('div');
      bar.className = 'progress-bar';
      bar.style.height = `${(value / max) * 100}%`;
      chart.appendChild(bar);
    });
    if (total) total.textContent = state.widgetData.progressTotal || '12時間20分';
  }

  function renderNotifications() {
    const notificationList = document.getElementById('notificationList');
    if (!notificationList) return;
    notificationList.innerHTML = '';
    (state.widgetData.notifications || []).forEach((entry, index) => {
      const li = document.createElement('li');
      li.innerHTML = `<span>${entry}</span>`;
      const del = document.createElement('button');
      del.className = 'ghost';
      del.textContent = window.i18n.t('dashboard.remove');
      del.onclick = () => {
        state.widgetData.notifications.splice(index, 1);
        renderNotifications();
        queueSaveLayout();
      };
      li.appendChild(del);
      notificationList.appendChild(li);
    });
  }

  function bindWidgetActions() {
    document.getElementById('chatSendBtn')?.addEventListener('click', window.chatModule.send);
    document.getElementById('imageGenerateBtn')?.addEventListener('click', window.imageModule.generate);

    document.getElementById('timerStartBtn')?.addEventListener('click', window.timerModule.start);
    document.getElementById('timerStopBtn')?.addEventListener('click', window.timerModule.stop);
    document.getElementById('timerResetBtn')?.addEventListener('click', window.timerModule.reset);

    document.getElementById('noteAddBtn')?.addEventListener('click', async () => {
      const text = document.getElementById('noteInput').value.trim();
      if (!text) return;
      const result = await window.authApi.api('/api/dashboard/notes', {
        method: 'POST',
        body: JSON.stringify({ text })
      });
      state.notes.push(result.note);
      document.getElementById('noteInput').value = '';
      renderNotes();
    });

    document.getElementById('taskAddBtn')?.addEventListener('click', async () => {
      const title = document.getElementById('taskInput').value.trim();
      const priority = document.getElementById('taskPriority').value;
      if (!title) return;
      const result = await window.authApi.api('/api/dashboard/tasks', {
        method: 'POST',
        body: JSON.stringify({ title, priority })
      });
      state.tasks.push(result.task);
      document.getElementById('taskInput').value = '';
      renderTasks();
    });

    document.getElementById('notificationAddBtn')?.addEventListener('click', () => {
      const input = document.getElementById('notificationInput');
      const text = input.value.trim();
      if (!text) return;
      state.widgetData.notifications = [text, ...(state.widgetData.notifications || [])].slice(0, 30);
      input.value = '';
      renderNotifications();
      queueSaveLayout();
    });
  }

  function bindGlobalActions() {
    document.getElementById('paletteToggleBtn')?.addEventListener('click', () => {
      document.getElementById('widgetPalette').classList.toggle('hidden');
    });
  }

  async function loadState() {
    const result = await window.authApi.api('/api/dashboard/state');
    state.tasks = result.tasks || [];
    state.notes = result.notes || [];
    state.theme = result.theme || { mode: 'system', custom: {} };
    state.layout = normalizeLayout(result.layout || {});
    state.widgetData = { ...state.widgetData, ...(state.layout.widgetData || {}) };
  }

  async function setupTracking() {
    const videoEl = document.getElementById('trackingVideo');
    if (!videoEl) return;
    trackingEngine = createTrackingEngine({
      videoEl,
      zoneEl: document.getElementById('trackingZone'),
      logFn: async (snapshot) => {
        await window.authApi.api('/api/tracking/log', {
          method: 'POST',
          body: JSON.stringify(snapshot)
        });
      }
    });
    videoEl.addEventListener('loadedmetadata', () => trackingEngine.updateZoneOverlay());

    bindTrackingUI({
      engine: trackingEngine,
      i18n: window.i18n,
      elements: {
        toggleBtn: document.getElementById('trackingToggleBtn'),
        gazeBtn: document.getElementById('gazeModeBtn'),
        writingBtn: document.getElementById('writingModeBtn'),
        focusEl: document.getElementById('trackingFocus'),
        eyeEl: document.getElementById('trackingEye'),
        handEl: document.getElementById('trackingHand'),
        postureEl: document.getElementById('trackingPosture'),
        logEl: document.getElementById('trackingLog'),
        zoneSizeInput: document.getElementById('zoneSize')
      }
    });
    const zoneSizeInput = document.getElementById('zoneSize');
    if (zoneSizeInput) trackingEngine.setZoneSize(Number(zoneSizeInput.value));
  }

  let themeManager = null;

  async function init() {
    if (!(await window.authApi.requireAuth())) return;
    await window.i18n.load('ja');
    await loadState();

    const { board, canvas, getSnapEnabled, bindSnapToggle } = initBoard();
    themeManager = createThemeManager({ board, i18n: window.i18n, saveTheme });

    widgetManager = createWidgetManager({
      board,
      canvas,
      widgetDefs,
      defaultLayout,
      widgetTemplate,
      i18n: window.i18n,
      layoutMap: state.layout.layoutMap,
      getSnapEnabled,
      onLayoutChange: () => queueSaveLayout()
    });

    widgetManager.initWidgets();
    bindSnapToggle();
    themeManager.applyTheme(state.theme);
    themeManager.bindThemeControls();

    bindWidgetActions();
    bindGlobalActions();

    renderNotes();
    renderTasks();
    renderProgress();
    renderNotifications();

    await window.chatModule.loadHistory();
    window.timerModule.init();
    await setupTracking();
  }

  return { init };
})();

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('board')) {
    dashboardModule.init();
  }
});

