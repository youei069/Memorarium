﻿const trackingModule = (() => {
  let stream = null;
  let intervalId = null;
  let running = false;

  function metric(base = 72, spread = 26) {
    return Math.max(0, Math.min(100, Math.round(base + (Math.random() * spread - spread / 2))));
  }

  function detectorLabel() {
    const hasMediaPipe = Boolean(window.Pose || window.Hands || window.FaceMesh);
    if (hasMediaPipe) {
      return 'MediaPipe 接続中';
    }
    return 'シミュレーションモード';
  }

  async function tick(statusEl, metricsEl) {
    const postureScore = metric(74, 36);
    const eyeFatigueScore = metric(70, 40);
    const handActivityScore = metric(75, 30);
    const gazeFocusScore = metric(68, 34);
    const skeletonScore = metric(73, 30);
    const warning = postureScore < 60 || gazeFocusScore < 60;

    statusEl.textContent = warning ? window.i18n.t('status.warningPosture') : window.i18n.t('status.goodPosture');
    statusEl.style.color = warning ? '#dc2626' : '#16a34a';

    metricsEl.textContent = [
      `モード: ${detectorLabel()}`,
      `姿勢: ${postureScore}`,
      `骨格: ${skeletonScore}`,
      `手: ${handActivityScore}`,
      `視線: ${gazeFocusScore}`,
      `目: ${eyeFatigueScore}`,
      `警告: ${warning}`
    ].join('\n');

    await window.authApi.api('/api/posture/log', {
      method: 'POST',
      body: JSON.stringify({
        postureScore,
        eyeFatigueScore,
        handActivityScore,
        gazeFocusScore,
        skeletonScore,
        warning
      })
    });
  }

  async function toggle() {
    const video = document.getElementById('postureVideo');
    const status = document.getElementById('postureStatus');
    const button = document.getElementById('postureToggleBtn');
    const metrics = document.getElementById('trackingMetrics');
    if (!video || !status || !button || !metrics) return;

    if (!running) {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = stream;
        running = true;
        button.textContent = window.i18n.t('tracking.stop');
        status.textContent = window.i18n.t('status.monitoring');
        await tick(status, metrics);
        intervalId = setInterval(() => {
          tick(status, metrics).catch((error) => {
            status.textContent = `${window.i18n.t('status.cameraError')}: ${error.message}`;
          });
        }, 5000);
      } catch (error) {
        status.textContent = `${window.i18n.t('status.cameraError')}: ${error.message}`;
      }
    } else {
      if (intervalId) clearInterval(intervalId);
      if (stream) stream.getTracks().forEach((track) => track.stop());
      stream = null;
      intervalId = null;
      running = false;
      button.textContent = window.i18n.t('tracking.start');
      status.textContent = window.i18n.t('status.monitoringStopped');
    }
  }

  return { toggle };
})();

window.trackingModule = trackingModule;

