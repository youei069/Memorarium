﻿const { withStore } = require('../utils/store');
const { newId } = require('../utils/auth');

function startSession(req, res) {
  const { workMinutes = 25, breakMinutes = 5, label = 'Focus Session' } = req.body;
  const session = {
    id: newId('timer'),
    userId: req.user.id,
    label,
    workMinutes: Number(workMinutes),
    breakMinutes: Number(breakMinutes),
    status: 'running',
    startedAt: Date.now(),
    endedAt: null
  };

  withStore((store) => {
    store.timerSessions.push(session);
  });

  return res.status(201).json({ session });
}

function stopSession(req, res) {
  const { sessionId } = req.body;
  let updated = null;

  withStore((store) => {
    const target = store.timerSessions.find((s) => s.id === sessionId && s.userId === req.user.id);
    if (target) {
      target.status = 'completed';
      target.endedAt = Date.now();
      updated = target;
    }
  });

  if (!updated) {
    return res.status(404).json({ error: 'セッションが見つかりません' });
  }

  return res.json({ session: updated });
}

function listSessions(req, res) {
  const sessions = withStore((store) => store.timerSessions.filter((s) => s.userId === req.user.id).slice(-50));
  return res.json({ sessions });
}

module.exports = {
  startSession,
  stopSession,
  listSessions
};

