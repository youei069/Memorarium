const path = require('path');
const fs = require('fs');
const { newId } = require('../utils/auth');

function generateImage(req, res) {
  const { prompt } = req.body;
  if (!prompt || prompt.length < 3) {
    return res.status(400).json({ error: 'Prompt is required.' });
  }

  const id = newId('img');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512"><rect width="100%" height="100%" fill="#1f2937"/><text x="50%" y="50%" fill="#f3f4f6" text-anchor="middle" font-size="20" font-family="Verdana">${prompt.replace(/[<>&]/g, '')}</text></svg>`;
  const fileName = `${id}.svg`;
  const fullPath = path.join(__dirname, '..', '..', 'uploads', fileName);
  fs.writeFileSync(fullPath, svg, 'utf8');

  return res.json({
    id,
    prompt,
    imageUrl: `/uploads/${fileName}`,
    note: 'Placeholder image generated locally. Replace with real AI image API integration.'
  });
}

module.exports = {
  generateImage
};
