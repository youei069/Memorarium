﻿export const defaultLayout = {
  chat: { x: 60, y: 60, w: 360, h: 360, hidden: false, minimized: false },
  notes: { x: 440, y: 80, w: 260, h: 220, hidden: false, minimized: false },
  timer: { x: 720, y: 260, w: 420, h: 300, hidden: false, minimized: false },
  progress: { x: 1140, y: 70, w: 360, h: 240, hidden: false, minimized: false },
  tasks: { x: 1140, y: 360, w: 320, h: 240, hidden: false, minimized: false },
  image: { x: 60, y: 460, w: 360, h: 260, hidden: false, minimized: false },
  tracking: { x: 460, y: 600, w: 520, h: 300, hidden: false, minimized: false },
  notifications: { x: 1140, y: 640, w: 360, h: 240, hidden: false, minimized: false }
};

export const widgetDefs = [
  { id: 'chat', titleKey: 'widget.chat', icon: 'AI', quick: true },
  { id: 'notes', titleKey: 'widget.notes', icon: 'N', quick: true },
  { id: 'tasks', titleKey: 'widget.tasks', icon: 'T', quick: true },
  { id: 'timer', titleKey: 'widget.timer', icon: 'P', quick: true },
  { id: 'image', titleKey: 'widget.image', icon: 'I', quick: true },
  { id: 'tracking', titleKey: 'widget.tracking', icon: 'TR', quick: true },
  { id: 'progress', titleKey: 'widget.progress', icon: 'G', quick: true },
  { id: 'notifications', titleKey: 'widget.notifications', icon: 'B', quick: true }
];

export function widgetTemplate(id) {
  if (id === 'chat') {
    return `
      <div id="chatHistory" class="panel-scroll"></div>
      <div class="row">
        <input id="chatInput" data-i18n-placeholder="chat.placeholder" placeholder="AIに相談する内容を入力">
        <button id="chatSendBtn" data-i18n="chat.send">送信</button>
      </div>`;
  }
  if (id === 'image') {
    return `
      <input id="imagePrompt" data-i18n-placeholder="image.placeholder" placeholder="生成したい画像の説明">
      <button id="imageGenerateBtn" data-i18n="image.generate">生成</button>
      <div id="imageResult" class="panel-scroll"></div>`;
  }
  if (id === 'timer') {
    return `
      <div class="row">
        <input id="workMinutes" type="number" min="1" value="25" data-i18n-title="timer.work" title="作業(分)">
        <input id="breakMinutes" type="number" min="1" value="5" data-i18n-title="timer.break" title="休憩(分)">
      </div>
      <div id="timerDisplay" class="timer-display">25:00</div>
      <div class="progress"><div id="timerProgress"></div></div>
      <div class="row">
        <button id="timerStartBtn" data-i18n="timer.start">開始</button>
        <button id="timerStopBtn" data-i18n="timer.stop">停止</button>
        <button id="timerResetBtn" data-i18n="timer.reset">リセット</button>
      </div>`;
  }
  if (id === 'notes') {
    return `
      <div class="row">
        <input id="noteInput" data-i18n-placeholder="notes.placeholder" placeholder="短いメモ">
        <button id="noteAddBtn" data-i18n="common.add">追加</button>
      </div>
      <ul id="noteList" class="list"></ul>`;
  }
  if (id === 'tasks') {
    return `
      <div class="row">
        <input id="taskInput" data-i18n-placeholder="task.placeholder" placeholder="新しいタスク">
        <select id="taskPriority">
          <option value="high">高</option>
          <option value="medium" selected>中</option>
          <option value="low">低</option>
        </select>
        <button id="taskAddBtn" data-i18n="common.add">追加</button>
      </div>
      <ul id="taskList" class="list"></ul>`;
  }
  if (id === 'progress') {
    return `
      <div class="row">
        <div>
          <div class="muted" data-i18n="progress.weekly">週間学習時間</div>
          <div id="progressTotal" style="font-size:1.4rem;font-weight:600;">12時間20分</div>
        </div>
        <div class="status-pill green" id="progressState">安定</div>
      </div>
      <div id="progressChart" class="progress-chart"></div>
      <div class="progress-labels">
        <span>月</span><span>火</span><span>水</span><span>木</span><span>金</span><span>土</span><span>日</span>
      </div>`;
  }
  if (id === 'notifications') {
    return `
      <div class="row">
        <input id="notificationInput" data-i18n-placeholder="notification.placeholder" placeholder="通知メッセージ">
        <button id="notificationAddBtn" data-i18n="common.add">追加</button>
      </div>
      <ul id="notificationList" class="list"></ul>`;
  }
  return `
    <div class="tracking-video">
      <video id="trackingVideo" autoplay muted playsinline></video>
      <div id="trackingZone" class="tracking-zone"></div>
    </div>
    <div class="tracking-grid">
      <div class="tracking-card">
        <div class="muted" data-i18n="tracking.focus">集中状態</div>
        <div id="trackingFocus" class="status-pill green">集中</div>
      </div>
      <div class="tracking-card">
        <div class="muted" data-i18n="tracking.eye">視線</div>
        <div id="trackingEye">検出中</div>
      </div>
      <div class="tracking-card">
        <div class="muted" data-i18n="tracking.hand">手の検出</div>
        <div id="trackingHand">検出中</div>
      </div>
      <div class="tracking-card">
        <div class="muted" data-i18n="tracking.posture">姿勢スコア</div>
        <div id="trackingPosture">--</div>
      </div>
    </div>
    <div class="row">
      <button id="trackingToggleBtn" data-i18n="tracking.start">トラッキング開始</button>
      <button id="gazeModeBtn" class="ghost" data-i18n="tracking.gaze">視線モード</button>
      <button id="writingModeBtn" class="ghost" data-i18n="tracking.writing">筆記モード</button>
    </div>
    <div class="row">
      <label class="muted" data-i18n="tracking.zone">学習ゾーン</label>
      <input id="zoneSize" type="range" min="30" max="90" value="60">
    </div>
    <div id="trackingLog" class="panel-scroll"></div>`;
}

