const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', 'data', 'store.json');

const defaultStore = {
  users: [],
  sessions: [],
  projects: [],
  tasks: [],
  notes: [],
  layouts: [],
  themes: [],
  chatHistory: [],
  postureLogs: [],
  trackingEvents: [],
  timerSessions: []
};

function ensureStoreFile() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(defaultStore, null, 2), 'utf8');
  }
}

function readStore() {
  ensureStoreFile();
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  try {
    const parsed = JSON.parse(raw);
    return { ...defaultStore, ...parsed };
  } catch {
    return { ...defaultStore };
  }
}

function writeStore(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function withStore(mutator) {
  const store = readStore();
  const result = mutator(store);
  writeStore(store);
  return result;
}

module.exports = {
  readStore,
  writeStore,
  withStore
};
