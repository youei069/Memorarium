﻿// Backward-compatible posture module wrapper.
window.postureModule = window.trackingModule || {
  toggle: async () => {}
};

