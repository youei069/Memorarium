﻿const i18n = (() => {
  const supported = ['ja', 'en'];
  let current = localStorage.getItem('memorarium_lang') || 'ja';
  let dict = {};

  async function load(lang = current) {
    const safeLang = supported.includes(lang) ? lang : 'ja';
    const response = await fetch(`i18n/${safeLang}.json`);
    dict = await response.json();
    current = safeLang;
    localStorage.setItem('memorarium_lang', current);
    apply();
    return current;
  }

  function t(key, fallback = '') {
    return dict[key] || fallback || key;
  }

  function apply(root = document) {
    root.querySelectorAll('[data-i18n]').forEach((el) => {
      el.textContent = t(el.dataset.i18n, el.textContent);
    });

    root.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
      el.placeholder = t(el.dataset.i18nPlaceholder, el.placeholder || '');
    });

    root.querySelectorAll('[data-i18n-title]').forEach((el) => {
      el.title = t(el.dataset.i18nTitle, el.title || '');
    });

    document.documentElement.lang = current;
  }

  function getLanguage() {
    return current;
  }

  return { load, t, apply, getLanguage, supported };
})();

window.i18n = i18n;

