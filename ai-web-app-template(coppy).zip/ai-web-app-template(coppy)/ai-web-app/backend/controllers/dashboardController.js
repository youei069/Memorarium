﻿const { withStore } = require('../utils/store');
const { newId } = require('../utils/auth');

function getState(req, res) {
  const state = withStore((store) => {
    const layout = store.layouts.find((l) => l.userId === req.user.id) || { widgets: {} };
    const theme = store.themes.find((t) => t.userId === req.user.id) || { mode: 'system', custom: {} };
    const tasks = store.tasks.filter((t) => t.userId === req.user.id);
    const notes = store.notes.filter((n) => n.userId === req.user.id);
    const projects = store.projects.filter((p) => p.userId === req.user.id);
    return { layout, theme, tasks, notes, projects };
  });

  return res.json(state);
}

function saveLayout(req, res) {
  const { widgets } = req.body;
  withStore((store) => {
    const existing = store.layouts.find((l) => l.userId === req.user.id);
    if (existing) {
      existing.widgets = widgets || {};
      existing.updatedAt = Date.now();
    } else {
      store.layouts.push({ id: newId('layout'), userId: req.user.id, widgets: widgets || {}, updatedAt: Date.now() });
    }
  });

  return res.json({ message: 'レイアウトを保存しました' });
}

function setTheme(req, res) {
  const { mode = 'system', custom = {}, shared = false, name = 'My Theme' } = req.body;
  withStore((store) => {
    const existing = store.themes.find((t) => t.userId === req.user.id);
    if (existing) {
      existing.mode = mode;
      existing.custom = custom;
      existing.shared = shared;
      existing.name = name;
      existing.updatedAt = Date.now();
    } else {
      store.themes.push({ id: newId('theme'), userId: req.user.id, mode, custom, shared, name, updatedAt: Date.now() });
    }
  });
  return res.json({ message: 'テーマを更新しました' });
}

function listSharedThemes(_req, res) {
  const sharedThemes = withStore((store) =>
    store.themes
      .filter((t) => t.shared)
      .map((t) => ({
        id: t.id,
        name: t.name,
        mode: t.mode,
        custom: t.custom
      }))
  );

  return res.json({ themes: sharedThemes });
}

function addTask(req, res) {
  const { title, projectId = null, priority = 'medium' } = req.body;
  if (!title) {
    return res.status(400).json({ error: 'タスク名は必須です' });
  }

  const task = { id: newId('task'), userId: req.user.id, title, projectId, priority, done: false, createdAt: Date.now() };
  withStore((store) => store.tasks.push(task));
  return res.status(201).json({ task });
}

function updateTask(req, res) {
  const { id, done, priority, title } = req.body;
  let task = null;
  withStore((store) => {
    const target = store.tasks.find((t) => t.id === id && t.userId === req.user.id);
    if (target) {
      if (typeof done === 'boolean') target.done = done;
      if (priority) target.priority = priority;
      if (title) target.title = title;
      task = target;
    }
  });
  if (!task) {
    return res.status(404).json({ error: 'タスクが見つかりません' });
  }
  return res.json({ task });
}

function deleteTask(req, res) {
  const { id } = req.params;
  withStore((store) => {
    store.tasks = store.tasks.filter((t) => !(t.id === id && t.userId === req.user.id));
  });
  return res.json({ message: 'タスクを削除しました' });
}

function addNote(req, res) {
  const { text } = req.body;
  if (!text) {
    return res.status(400).json({ error: 'メモ内容は必須です' });
  }
  const note = { id: newId('note'), userId: req.user.id, text, createdAt: Date.now() };
  withStore((store) => store.notes.push(note));
  return res.status(201).json({ note });
}

function deleteNote(req, res) {
  const { id } = req.params;
  withStore((store) => {
    store.notes = store.notes.filter((n) => !(n.id === id && n.userId === req.user.id));
  });
  return res.json({ message: 'メモを削除しました' });
}

module.exports = {
  getState,
  saveLayout,
  setTheme,
  listSharedThemes,
  addTask,
  updateTask,
  deleteTask,
  addNote,
  deleteNote
};

