﻿const AUTH_ERROR_MAP = {
  'Email and password are required.': 'メールアドレスとパスワードを入力してください。',
  'Email and password (8+ chars) are required.': 'メールアドレスと8文字以上のパスワードが必要です。',
  'Email already registered': 'このメールアドレスは既に登録されています。',
  'Invalid credentials': 'メールアドレスまたはパスワードが正しくありません。',
  'Unauthorized': '認証が必要です。',
  'Session expired': 'セッションの有効期限が切れました。'
};

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const original = data.error || 'Request failed';
    throw new Error(AUTH_ERROR_MAP[original] || original);
  }
  return data;
}

async function login() {
  const email = document.getElementById('email')?.value.trim();
  const password = document.getElementById('password')?.value;
  const status = document.getElementById('authStatus');
  try {
    await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
    window.location.href = 'dashboard.html';
  } catch (error) {
    if (status) status.textContent = error.message;
  }
}

async function register() {
  const email = document.getElementById('email')?.value.trim();
  const password = document.getElementById('password')?.value;
  const status = document.getElementById('authStatus');
  try {
    await api('/api/auth/register', { method: 'POST', body: JSON.stringify({ email, password }) });
    await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
    window.location.href = 'dashboard.html';
  } catch (error) {
    if (status) status.textContent = error.message;
  }
}

async function requireAuth() {
  try {
    await api('/api/auth/me');
    return true;
  } catch {
    window.location.href = 'login.html';
    return false;
  }
}

async function logout() {
  try {
    await api('/api/auth/logout', { method: 'POST' });
  } finally {
    window.location.href = 'login.html';
  }
}

window.authApi = { api, login, register, requireAuth, logout };

document.getElementById('loginBtn')?.addEventListener('click', login);
document.getElementById('registerBtn')?.addEventListener('click', register);
document.getElementById('logoutBtn')?.addEventListener('click', logout);

