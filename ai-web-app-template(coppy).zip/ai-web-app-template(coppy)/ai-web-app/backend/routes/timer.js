const express = require('express');
const controller = require('../controllers/timerController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/start', authMiddleware, controller.startSession);
router.post('/stop', authMiddleware, controller.stopSession);
router.get('/sessions', authMiddleware, controller.listSessions);

module.exports = router;
