const { withStore } = require('../utils/store');
const { orchestrateChat } = require('../services/aiOrchestrator');
const { newId } = require('../utils/auth');

function chat(req, res) {
  const { message } = req.body;
  if (!message) {
    return res.status(400).json({ error: 'Message is required.' });
  }

  const ai = orchestrateChat(message);
  const userMessage = { id: newId('msg'), userId: req.user.id, role: 'user', text: message, createdAt: Date.now() };
  const aiMessage = { id: ai.id, userId: req.user.id, role: 'assistant', text: ai.reply, actions: ai.actions, createdAt: Date.now() };

  withStore((store) => {
    store.chatHistory.push(userMessage, aiMessage);
  });

  return res.json({ reply: aiMessage.text, actions: aiMessage.actions });
}

function history(req, res) {
  const messages = withStore((store) => store.chatHistory.filter((m) => m.userId === req.user.id).slice(-50));
  return res.json({ messages });
}

module.exports = {
  chat,
  history
};
