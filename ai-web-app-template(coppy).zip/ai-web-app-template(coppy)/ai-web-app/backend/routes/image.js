const express = require('express');
const controller = require('../controllers/imageController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/', authMiddleware, controller.generateImage);

module.exports = router;
