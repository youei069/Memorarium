const fs = require('fs');

function analyzeText(content) {
  const words = content.trim().split(/\s+/).filter(Boolean);
  const lines = content.split(/\r?\n/).length;
  return {
    type: 'text',
    words: words.length,
    lines,
    preview: content.slice(0, 240)
  };
}

function analyzeCsv(content) {
  const rows = content.split(/\r?\n/).filter(Boolean);
  const columns = rows[0] ? rows[0].split(',').length : 0;
  return {
    type: 'csv',
    rows: rows.length,
    columns,
    header: rows[0] || ''
  };
}

function analyzeFile(req, res) {
  if (!req.file) {
    return res.status(400).json({ error: 'File is required.' });
  }

  const ext = (req.file.originalname.split('.').pop() || '').toLowerCase();
  const content = fs.readFileSync(req.file.path, 'utf8');
  let analysis;

  if (ext === 'txt' || ext === 'md') {
    analysis = analyzeText(content);
  } else if (ext === 'csv') {
    analysis = analyzeCsv(content);
  } else if (ext === 'pdf') {
    analysis = {
      type: 'pdf',
      bytes: req.file.size,
      note: 'PDF deep parsing is mocked in this baseline. Integrate a PDF parser service for text extraction.'
    };
  } else {
    analysis = {
      type: ext || 'unknown',
      bytes: req.file.size,
      note: 'Unsupported type for deep analysis in baseline mode.'
    };
  }

  return res.json({
    file: {
      originalName: req.file.originalname,
      mimeType: req.file.mimetype,
      size: req.file.size
    },
    analysis
  });
}

module.exports = {
  analyzeFile
};
