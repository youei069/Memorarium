const express = require('express');
const controller = require('../controllers/dashboardController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/state', authMiddleware, controller.getState);
router.post('/layout', authMiddleware, controller.saveLayout);
router.post('/theme', authMiddleware, controller.setTheme);
router.get('/themes/shared', controller.listSharedThemes);
router.post('/tasks', authMiddleware, controller.addTask);
router.patch('/tasks', authMiddleware, controller.updateTask);
router.delete('/tasks/:id', authMiddleware, controller.deleteTask);
router.post('/notes', authMiddleware, controller.addNote);
router.delete('/notes/:id', authMiddleware, controller.deleteNote);

module.exports = router;
