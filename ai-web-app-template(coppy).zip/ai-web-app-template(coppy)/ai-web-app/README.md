﻿# Memorarium

Memorarium は、ウィジェット型ダッシュボードを備えたAI学習ワークスペースです。

## 今回の改善点
- ガラス調のホワイトボードUI（無限キャンバス風）と浮遊ウィジェット。
- ボトムツールバーからワンクリックでウィジェット追加。
  - AIチャット / ノート / タスク / タイマー / 画像生成 / Tracking Monitor / 学習進捗 / 通知
- ウィジェットはドラッグ / リサイズ / 折りたたみ / 削除に対応し、配置を保存。
- 任意のスナップ（グリッド吸着）トグル。
- MediaPipe/TensorFlow.js 対応の視線・筆記トラッキング（未導入時はシミュレーション）。
- 集中状態は「集中 / ページめくり / 注意が必要」を色で表示。
- `frontend/modules` に UI / widgets / tracking を分離してモジュール化。
- バックエンドにトラッキングログAPIと `tracking_events` スキーマを追加。
- 画面表記は日本語に統一。

## セットアップ
1. 依存関係をインストール
```bash
npm install
```
2. サーバー起動
```bash
npm run dev
```
3. ブラウザで開く
- `http://localhost:3000/index.html`

## メモ
- 開発時の保存は JSON 形式（`backend/data/store.json`）です。
- 本番では永続DB + MediaPipe/TensorFlow.js の実検出パイプラインに置き換えてください。
- アップロードファイルは `uploads/` 配下に保存されます。

