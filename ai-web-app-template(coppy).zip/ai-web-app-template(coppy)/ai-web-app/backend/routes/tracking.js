﻿const express = require('express');
const controller = require('../controllers/trackingController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/log', authMiddleware, controller.logTracking);
router.get('/logs', authMiddleware, controller.getTrackingEvents);

module.exports = router;

