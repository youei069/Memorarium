﻿const { parseCookies, SESSION_TTL_MS } = require('../utils/auth');
const { withStore } = require('../utils/store');

function authMiddleware(req, res, next) {
  const cookies = parseCookies(req.headers.cookie || '');
  const token = cookies.session_token;

  if (!token) {
    return res.status(401).json({ error: '認証が必要です。' });
  }

  let user = null;
  withStore((store) => {
    const now = Date.now();
    store.sessions = store.sessions.filter((s) => now - s.createdAt < SESSION_TTL_MS);
    const session = store.sessions.find((s) => s.token === token);
    if (session) {
      user = store.users.find((u) => u.id === session.userId) || null;
    }
  });

  if (!user) {
    return res.status(401).json({ error: 'セッションの有効期限が切れました。' });
  }

  req.user = { id: user.id, email: user.email };
  return next();
}

module.exports = authMiddleware;

