﻿const DEFAULT_ZONE = { widthPct: 0.6, heightPct: 0.35, centerY: 0.7 };

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function distance(a, b) {
  if (!a || !b) return 1;
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

function createSmoothScore() {
  let current = 72;
  return (target) => {
    current += (target - current) * 0.15;
    return Math.round(current);
  };
}

export function createTrackingEngine({ videoEl, zoneEl, logFn }) {
  const listeners = new Set();
  let running = false;
  let stream = null;
  let lastFrameTime = 0;
  let lastLogTime = 0;
  let mode = 'gaze';
  let gazeOutsideSince = null;
  let pageTurningUntil = 0;
  let pageTurnCandidateAt = 0;
  let lastGazeInside = true;
  let lastWrist = null;
  let wristHistory = [];
  let faceMesh = null;
  let hands = null;
  let faceResult = null;
  let handsResult = null;
  let zone = { ...DEFAULT_ZONE };
  const smoothPosture = createSmoothScore();
  const smoothEye = createSmoothScore();
  const smoothHand = createSmoothScore();

  function setMode(next) {
    mode = next;
    notify();
  }

  function setZoneSize(valuePct) {
    zone.widthPct = clamp(valuePct / 100, 0.3, 0.9);
    zone.heightPct = clamp(valuePct / 100, 0.2, 0.6);
    notify();
  }

  function getZoneRect() {
    const width = videoEl?.videoWidth || 640;
    const height = videoEl?.videoHeight || 480;
    const zoneWidth = width * zone.widthPct;
    const zoneHeight = height * zone.heightPct;
    const x = (width - zoneWidth) / 2;
    const y = height * zone.centerY - zoneHeight / 2;
    return { x, y, width: zoneWidth, height: zoneHeight };
  }

  function updateZoneOverlay() {
    if (!zoneEl || !videoEl || !videoEl.videoWidth || !videoEl.videoHeight) return;
    const rect = getZoneRect();
    zoneEl.style.left = `${(rect.x / videoEl.videoWidth) * 100}%`;
    zoneEl.style.top = `${(rect.y / videoEl.videoHeight) * 100}%`;
    zoneEl.style.width = `${(rect.width / videoEl.videoWidth) * 100}%`;
    zoneEl.style.height = `${(rect.height / videoEl.videoHeight) * 100}%`;
  }

  function notify(snapshot) {
    const payload = snapshot || buildSnapshot();
    listeners.forEach((listener) => listener(payload));
  }

  function buildSnapshot() {
    const now = Date.now();
    const zoneRect = getZoneRect();
    const gazeInside = Boolean(lastGazeInside);
    const isPageTurning = pageTurningUntil > now;
    const gazeState = isPageTurning
      ? 'PAGE_TURNING'
      : gazeInside
        ? 'STUDYING'
        : now - (gazeOutsideSince || now) > 3000
          ? 'LOOKING_AWAY'
          : 'AWAY_SHORT';

    return {
      mode,
      zoneRect,
      gazeState,
      gazeInside,
      isPageTurning,
      handDetected: Boolean(handsResult && handsResult.multiHandLandmarks?.length),
      writingState: buildWritingState(),
      postureScore: smoothPosture(70 + Math.random() * 20),
      eyeScore: smoothEye(68 + Math.random() * 24),
      handScore: smoothHand(72 + Math.random() * 22)
    };
  }

  function buildWritingState() {
    if (!handsResult?.multiHandLandmarks?.length) return 'NONE';
    const hand = handsResult.multiHandLandmarks[0];
    const thumb = hand[4];
    const index = hand[8];
    const middle = hand[12];
    const pinch = distance(thumb, index) < 0.06;
    const support = distance(middle, index) < 0.09;
    const holding = pinch && support;

    const movement = wristHistory.length > 3
      ? wristHistory.slice(-6).reduce((sum, p, i, arr) => {
          if (i === 0) return sum;
          return sum + distance(p, arr[i - 1]);
        }, 0) / 5
      : 0;
    const writing = holding && movement > 0.003 && movement < 0.02;
    return writing ? 'WRITING' : holding ? 'HOLDING_PENCIL' : 'HAND_PRESENT';
  }

  function updateGazeState() {
    const now = Date.now();
    const rect = getZoneRect();
    let gazeInside = false;

    if (faceResult?.multiFaceLandmarks?.length) {
      const landmarks = faceResult.multiFaceLandmarks[0];
      const nose = landmarks[1] || landmarks[4];
      if (nose && videoEl.videoWidth) {
        const x = nose.x * videoEl.videoWidth;
        const y = nose.y * videoEl.videoHeight;
        gazeInside = x >= rect.x && x <= rect.x + rect.width && y >= rect.y && y <= rect.y + rect.height;
      }
    }

    if (!faceResult) {
      gazeInside = Math.random() > 0.15;
    }

    if (!gazeInside) {
      if (!gazeOutsideSince) gazeOutsideSince = now;
    } else {
      gazeOutsideSince = null;
    }

    if (!lastGazeInside && gazeInside && pageTurnCandidateAt && now - pageTurnCandidateAt <= 3000) {
      pageTurningUntil = now + 2000;
      pageTurnCandidateAt = 0;
    } else if (pageTurnCandidateAt && now - pageTurnCandidateAt > 3000) {
      pageTurnCandidateAt = 0;
    }

    lastGazeInside = gazeInside;
  }

  function updateHandMotion() {
    if (!handsResult?.multiHandLandmarks?.length) {
      wristHistory = [];
      lastWrist = null;
      return false;
    }
    const hand = handsResult.multiHandLandmarks[0];
    const wrist = hand[0];
    if (wrist) {
      if (lastWrist) {
        const speed = distance(wrist, lastWrist);
        if (speed > 0.05) {
          pageTurnCandidateAt = Date.now();
        }
      }
      lastWrist = wrist;
      wristHistory.push(wrist);
      if (wristHistory.length > 20) wristHistory = wristHistory.slice(-20);
    }
    return true;
  }

  async function initDetectors() {
    if (window.FaceMesh) {
      faceMesh = new window.FaceMesh({
        locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
      });
      faceMesh.setOptions({
        maxNumFaces: 1,
        refineLandmarks: true,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
      });
      faceMesh.onResults((res) => {
        faceResult = res;
      });
    }

    if (window.Hands) {
      hands = new window.Hands({
        locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
      });
      hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
      });
      hands.onResults((res) => {
        handsResult = res;
      });
    }
  }

  async function processFrame(now) {
    if (!running) return;
    if (!lastFrameTime) lastFrameTime = now;
    const delta = now - lastFrameTime;
    if (delta < 33) {
      requestAnimationFrame(processFrame);
      return;
    }
    lastFrameTime = now;

    if (faceMesh && videoEl.readyState >= 2) {
      await faceMesh.send({ image: videoEl });
    }
    if (hands && videoEl.readyState >= 2) {
      await hands.send({ image: videoEl });
    }

    updateZoneOverlay();
    updateGazeState();
    updateHandMotion();

    const snapshot = buildSnapshot();
    notify(snapshot);

    if (logFn && now - lastLogTime > 5000) {
      lastLogTime = now;
      logFn(snapshot).catch(() => {});
    }

    requestAnimationFrame(processFrame);
  }

  async function start() {
    if (running) return;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoEl.srcObject = stream;
      await initDetectors();
      running = true;
      requestAnimationFrame(processFrame);
    } catch (error) {
      notify({ error: error.message, ...buildSnapshot() });
    }
  }

  function stop() {
    if (!running) return;
    running = false;
    if (stream) stream.getTracks().forEach((track) => track.stop());
    stream = null;
  }

  function subscribe(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }

  return {
    start,
    stop,
    subscribe,
    setMode,
    setZoneSize,
    updateZoneOverlay
  };
}

