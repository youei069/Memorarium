const express = require('express');
const controller = require('../controllers/chatController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/', authMiddleware, controller.chat);
router.get('/history', authMiddleware, controller.history);

module.exports = router;
