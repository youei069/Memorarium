AI assistant instructions:

- Follow folder structure and keep routes/controllers/middleware modular.
- Add new AI modules under `backend/controllers` + `backend/routes` + `frontend/js`.
- Keep async API interactions promise-based and non-blocking for UI.
- Protect sensitive endpoints with `authMiddleware`.
- Log backend errors with ISO timestamps.
- For major feature additions, update `README.md` and `database/schema.sql`.
