﻿const { withStore } = require('../utils/store');
const { newId } = require('../utils/auth');

function logPosture(req, res) {
  const {
    postureScore,
    eyeFatigueScore,
    handActivityScore,
    gazeFocusScore,
    skeletonScore,
    warning
  } = req.body;

  const entry = {
    id: newId('posture'),
    userId: req.user.id,
    postureScore: Number(postureScore || 0),
    eyeFatigueScore: Number(eyeFatigueScore || 0),
    handActivityScore: Number(handActivityScore || 0),
    gazeFocusScore: Number(gazeFocusScore || 0),
    skeletonScore: Number(skeletonScore || 0),
    warning: Boolean(warning),
    createdAt: Date.now()
  };

  withStore((store) => {
    store.postureLogs.push(entry);
  });

  return res.status(201).json({ message: 'トラッキングデータを保存しました', entry });
}

function getPostureLogs(req, res) {
  const logs = withStore((store) => store.postureLogs.filter((p) => p.userId === req.user.id).slice(-100));
  return res.json({ logs });
}

module.exports = {
  logPosture,
  getPostureLogs
};

