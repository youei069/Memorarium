﻿const chatModule = (() => {
  async function loadHistory() {
    const box = document.getElementById('chatHistory');
    if (!box) return;
    const { messages } = await window.authApi.api('/api/chat/history');
    box.innerHTML = '';
    messages.forEach((m) => appendMessage(m.role, m.text));
  }

  function appendMessage(role, text) {
    const box = document.getElementById('chatHistory');
    if (!box) return;
    const p = document.createElement('p');
    p.className = role === 'assistant' ? 'message-ai' : 'message-user';
    const who = role === 'assistant' ? 'AI' : 'あなた';
    p.textContent = `${who}: ${text}`;
    box.appendChild(p);
    box.scrollTop = box.scrollHeight;
  }

  async function send() {
    const input = document.getElementById('chatInput');
    if (!input || !input.value.trim()) return;
    const text = input.value.trim();
    appendMessage('user', text);
    input.value = '';

    try {
      const result = await window.authApi.api('/api/chat', {
        method: 'POST',
        body: JSON.stringify({ message: text })
      });
      appendMessage('assistant', result.reply);
    } catch (error) {
      appendMessage('assistant', `エラー: ${error.message}`);
    }
  }

  return { loadHistory, send };
})();

window.chatModule = chatModule;

