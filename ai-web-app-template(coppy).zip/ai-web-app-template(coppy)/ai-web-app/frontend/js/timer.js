﻿const timerModule = (() => {
  let intervalId = null;
  let remaining = 1500;
  let total = 1500;
  let activeSessionId = null;

  function render() {
    const display = document.getElementById('timerDisplay');
    const progress = document.getElementById('timerProgress');
    if (!display || !progress) return;

    const mm = String(Math.floor(remaining / 60)).padStart(2, '0');
    const ss = String(remaining % 60).padStart(2, '0');
    display.textContent = `${mm}:${ss}`;
    progress.style.width = `${Math.max(0, Math.min(100, ((total - remaining) / total) * 100))}%`;
  }

  async function start() {
    const work = Number(document.getElementById('workMinutes')?.value || 25);
    const rest = Number(document.getElementById('breakMinutes')?.value || 5);
    if (!intervalId) {
      if (remaining === total) {
        total = work * 60;
        remaining = total;
      }

      const session = await window.authApi.api('/api/timer/start', {
        method: 'POST',
        body: JSON.stringify({ workMinutes: work, breakMinutes: rest })
      });
      activeSessionId = session.session.id;

      intervalId = setInterval(async () => {
        remaining -= 1;
        render();
        if (remaining <= 0) {
          clearInterval(intervalId);
          intervalId = null;
          const title = 'ポモドーロ終了';
          const body = '休憩に入りましょう。';
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(title, { body });
          } else {
            alert(`${title}\n${body}`);
          }
          if (activeSessionId) {
            await window.authApi.api('/api/timer/stop', {
              method: 'POST',
              body: JSON.stringify({ sessionId: activeSessionId })
            });
            activeSessionId = null;
          }
        }
      }, 1000);
    }
  }

  async function stop() {
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
    if (activeSessionId) {
      await window.authApi.api('/api/timer/stop', {
        method: 'POST',
        body: JSON.stringify({ sessionId: activeSessionId })
      });
      activeSessionId = null;
    }
  }

  function reset() {
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
    total = Number(document.getElementById('workMinutes')?.value || 25) * 60;
    remaining = total;
    render();
  }

  function init() {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
    reset();
  }

  return { start, stop, reset, init };
})();

window.timerModule = timerModule;

