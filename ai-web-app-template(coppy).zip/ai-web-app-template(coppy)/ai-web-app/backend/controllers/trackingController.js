﻿const { withStore } = require('../utils/store');
const { newId } = require('../utils/auth');
const logger = require('../utils/logger');

function logTracking(req, res) {
  try {
    const {
      mode,
      gazeState,
      gazeInside,
      isPageTurning,
      handDetected,
      writingState,
      postureScore,
      eyeScore,
      handScore
    } = req.body;

    const entry = {
      id: newId('tracking'),
      userId: req.user.id,
      mode: mode || 'gaze',
      gazeState: gazeState || 'STUDYING',
      gazeInside: Boolean(gazeInside),
      isPageTurning: Boolean(isPageTurning),
      handDetected: Boolean(handDetected),
      writingState: writingState || 'NONE',
      postureScore: Number(postureScore || 0),
      eyeScore: Number(eyeScore || 0),
      handScore: Number(handScore || 0),
      createdAt: Date.now()
    };

    withStore((store) => {
      store.trackingEvents.push(entry);
    });

    return res.status(201).json({ message: 'トラッキングデータを保存しました', entry });
  } catch (error) {
    logger.error('Tracking log error', { message: error.message, stack: error.stack });
    return res.status(500).json({ error: 'Internal server error' });
  }
}

function getTrackingEvents(req, res) {
  const logs = withStore((store) => store.trackingEvents.filter((p) => p.userId === req.user.id).slice(-100));
  return res.json({ logs });
}

module.exports = {
  logTracking,
  getTrackingEvents
};

