CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE projects (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  project_id TEXT,
  title TEXT NOT NULL,
  priority TEXT DEFAULT 'medium',
  done INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (project_id) REFERENCES projects(id)
);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  token TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE timer_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  label TEXT,
  work_minutes INTEGER,
  break_minutes INTEGER,
  status TEXT,
  started_at DATETIME,
  ended_at DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE posture_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  posture_score REAL,
  eye_fatigue_score REAL,
  hand_activity_score REAL,
  gaze_focus_score REAL,
  skeleton_score REAL,
  warning INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE notes (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE dashboard_layouts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  layout_json TEXT NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE theme_settings (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT,
  mode TEXT DEFAULT 'system',
  custom_json TEXT,
  shared INTEGER DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE tracking_events (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  mode TEXT,
  gaze_state TEXT,
  gaze_inside INTEGER,
  is_page_turning INTEGER,
  hand_detected INTEGER,
  writing_state TEXT,
  posture_score REAL,
  eye_score REAL,
  hand_score REAL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
