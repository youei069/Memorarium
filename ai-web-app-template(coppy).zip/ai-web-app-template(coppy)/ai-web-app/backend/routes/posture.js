const express = require('express');
const controller = require('../controllers/postureController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/log', authMiddleware, controller.logPosture);
router.get('/logs', authMiddleware, controller.getPostureLogs);

module.exports = router;
