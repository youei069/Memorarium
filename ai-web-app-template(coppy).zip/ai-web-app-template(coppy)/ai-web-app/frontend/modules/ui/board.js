﻿export function initBoard() {
  const board = document.getElementById('board');
  const canvas = document.getElementById('canvas');
  const snapToggle = document.getElementById('snapToggle');
  const storedSnap = localStorage.getItem('memorarium_snap');
  if (snapToggle) {
    snapToggle.checked = storedSnap ? storedSnap === 'true' : true;
  }

  function getSnapEnabled() {
    return snapToggle ? snapToggle.checked : true;
  }

  function bindSnapToggle() {
    snapToggle?.addEventListener('change', () => {
      localStorage.setItem('memorarium_snap', String(snapToggle.checked));
    });
  }

  return { board, canvas, getSnapEnabled, bindSnapToggle };
}

