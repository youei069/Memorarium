﻿export function createWidgetManager({
  board,
  canvas,
  widgetDefs,
  defaultLayout,
  widgetTemplate,
  i18n,
  layoutMap,
  getSnapEnabled,
  onLayoutChange
}) {
  const snapSize = 16;

  function ensureCanvasSize(widget) {
    const rect = widget.getBoundingClientRect();
    const canvasRect = canvas.getBoundingClientRect();
    const right = widget.offsetLeft + rect.width + 200;
    const bottom = widget.offsetTop + rect.height + 200;
    if (right > canvas.offsetWidth) canvas.style.width = `${Math.max(right, canvas.offsetWidth)}px`;
    if (bottom > canvas.offsetHeight) canvas.style.height = `${Math.max(bottom, canvas.offsetHeight)}px`;
  }

  function snap(value) {
    return Math.round(value / snapSize) * snapSize;
  }

  function persistWidgetBox(widget) {
    const id = widget.dataset.widget;
    if (!layoutMap[id]) layoutMap[id] = { ...defaultLayout[id] };
    const map = layoutMap[id];
    map.x = parseInt(widget.style.left || '0', 10);
    map.y = parseInt(widget.style.top || '0', 10);
    map.w = Math.round(widget.getBoundingClientRect().width);
    map.h = Math.round(widget.getBoundingClientRect().height);
    map.hidden = widget.classList.contains('hidden');
    map.minimized = widget.classList.contains('minimized');
  }

  function observeResize(widget) {
    const observer = new ResizeObserver(() => {
      persistWidgetBox(widget);
      ensureCanvasSize(widget);
      onLayoutChange();
    });
    observer.observe(widget);
  }

  function makeDraggable(widget) {
    const header = widget.querySelector('.widget-header');
    if (!header) return;

    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    header.addEventListener('pointerdown', (event) => {
      if (window.innerWidth < 1100) return;
      dragging = true;
      header.setPointerCapture(event.pointerId);
      const rect = widget.getBoundingClientRect();
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      widget.style.zIndex = String(Date.now() % 100000);
      header.style.cursor = 'grabbing';
    });

    header.addEventListener('pointermove', (event) => {
      if (!dragging) return;
      const boardRect = board.getBoundingClientRect();
      const x = Math.max(0, event.clientX - boardRect.left + board.scrollLeft - offsetX);
      const y = Math.max(0, event.clientY - boardRect.top + board.scrollTop - offsetY);
      const finalX = getSnapEnabled() ? snap(x) : x;
      const finalY = getSnapEnabled() ? snap(y) : y;
      widget.style.left = `${finalX}px`;
      widget.style.top = `${finalY}px`;
    });

    header.addEventListener('pointerup', (event) => {
      if (!dragging) return;
      dragging = false;
      header.releasePointerCapture(event.pointerId);
      header.style.cursor = 'grab';
      persistWidgetBox(widget);
      ensureCanvasSize(widget);
      onLayoutChange();
    });
  }

  function createWidget(id) {
    if (canvas.querySelector(`[data-widget="${id}"]`)) return;
    const map = { ...defaultLayout[id], ...(layoutMap[id] || {}) };
    if (!map.w) map.w = defaultLayout[id].w;
    if (!map.h) map.h = defaultLayout[id].h;
    layoutMap[id] = map;
    const def = widgetDefs.find((x) => x.id === id);

    const el = document.createElement('section');
    el.className = 'widget';
    el.dataset.widget = id;
    el.style.left = `${map.x}px`;
    el.style.top = `${map.y}px`;
    el.style.width = `${map.w}px`;
    el.style.height = `${map.h}px`;

    if (map.hidden) el.classList.add('hidden');
    if (map.minimized) el.classList.add('minimized');

    el.innerHTML = `
      <div class="widget-header">
        <div class="widget-title">
          <span class="widget-icon">${def.icon}</span>
          <strong data-i18n="${def.titleKey}">${i18n.t(def.titleKey)}</strong>
        </div>
        <div class="widget-actions">
          <button class="ghost" data-action="minimize" data-i18n="dashboard.minimize">最小化</button>
          <button class="ghost" data-action="remove" data-i18n="dashboard.remove">削除</button>
        </div>
      </div>
      <div class="widget-body">${widgetTemplate(id)}</div>`;

    canvas.appendChild(el);
    makeDraggable(el);
    observeResize(el);
    ensureCanvasSize(el);

    el.querySelector('[data-action="remove"]').addEventListener('click', () => {
      layoutMap[id].hidden = true;
      el.classList.add('hidden');
      onLayoutChange();
      refreshPalette();
      renderDock();
    });

    el.querySelector('[data-action="minimize"]').addEventListener('click', () => {
      const isMinimized = el.classList.toggle('minimized');
      layoutMap[id].minimized = isMinimized;
      onLayoutChange();
    });

    i18n.apply(el);
  }

  function toggleWidget(id) {
    const widget = canvas.querySelector(`[data-widget="${id}"]`);
    if (!widget) return;
    const currentlyHidden = widget.classList.contains('hidden');
    widget.classList.toggle('hidden', !currentlyHidden);
    layoutMap[id].hidden = !currentlyHidden;
    onLayoutChange();
    refreshPalette();
    renderDock();
  }

  function refreshPalette() {
    const palette = document.getElementById('paletteList');
    if (!palette) return;
    palette.innerHTML = '';

    widgetDefs.forEach((def) => {
      const hidden = layoutMap[def.id]?.hidden;
      const row = document.createElement('div');
      row.className = 'palette-item';
      row.innerHTML = `<span>${i18n.t(def.titleKey)}</span>`;
      const btn = document.createElement('button');
      btn.textContent = hidden ? i18n.t('dashboard.addWidget') : i18n.t('dashboard.remove');
      btn.className = hidden ? '' : 'ghost';
      btn.addEventListener('click', () => toggleWidget(def.id));
      row.appendChild(btn);
      palette.appendChild(row);
    });
  }

  function renderDock() {
    const dock = document.getElementById('dockButtons');
    if (!dock) return;
    dock.innerHTML = '';

    widgetDefs.forEach((def) => {
      const hidden = layoutMap[def.id]?.hidden;
      const btn = document.createElement('button');
      btn.className = `dock-btn${hidden ? '' : ' active'}`;
      btn.innerHTML = `
        <span class="dock-icon">${def.icon}</span>
        <span>${i18n.t(def.titleKey)}</span>`;
      btn.addEventListener('click', () => toggleWidget(def.id));
      dock.appendChild(btn);
    });
  }

  function initWidgets() {
    widgetDefs.forEach((def) => {
      if (!layoutMap[def.id]) layoutMap[def.id] = { ...defaultLayout[def.id] };
      createWidget(def.id);
    });
    refreshPalette();
    renderDock();
  }

  return {
    initWidgets,
    toggleWidget,
    refreshPalette,
    renderDock,
    persistWidgetBox
  };
}

