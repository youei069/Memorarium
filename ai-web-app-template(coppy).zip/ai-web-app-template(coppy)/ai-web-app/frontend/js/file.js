﻿const fileModule = (() => {
  async function analyze() {
    const input = document.getElementById('fileInput');
    const output = document.getElementById('fileResult');
    if (!input || !output || !input.files?.length) return;

    const file = input.files[0];
    const form = new FormData();
    form.append('file', file);
    output.textContent = 'アップロード・解析中...';

    try {
      const response = await fetch('/api/file/analyze', {
        method: 'POST',
        credentials: 'include',
        body: form
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || '解析に失敗しました');
      }
      output.textContent = JSON.stringify(data, null, 2);
    } catch (error) {
      output.textContent = `エラー: ${error.message}`;
    }
  }

  return { analyze };
})();

window.fileModule = fileModule;

