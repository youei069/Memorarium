const { newId } = require('../utils/auth');

function orchestrateChat(message) {
  const text = (message || '').toLowerCase();
  const actions = [];

  if (text.includes('image') || text.includes('draw') || text.includes('generate')) {
    actions.push({
      agent: 'image-agent',
      suggestion: 'Open the image widget and submit a prompt for generation.'
    });
  }

  if (text.includes('file') || text.includes('pdf') || text.includes('analyze')) {
    actions.push({
      agent: 'file-agent',
      suggestion: 'Upload a document in the file analyzer for structured insights.'
    });
  }

  if (text.includes('focus') || text.includes('pomodoro') || text.includes('timer')) {
    actions.push({
      agent: 'timer-agent',
      suggestion: 'Start a 25/5 Pomodoro and review your top 3 tasks before the session.'
    });
  }

  if (text.includes('posture') || text.includes('neck') || text.includes('eye')) {
    actions.push({
      agent: 'posture-agent',
      suggestion: 'Enable posture monitoring and schedule micro-breaks every 30 minutes.'
    });
  }

  if (text.includes('task') || text.includes('priority') || text.includes('project')) {
    actions.push({
      agent: 'task-agent',
      suggestion: 'Prioritize tasks with urgency/impact scoring and move one to �gnow�h.'
    });
  }

  const reply = actions.length
    ? `I coordinated ${actions.length} internal agent(s). ${actions.map((a) => a.suggestion).join(' ')}`
    : 'I can help with planning, focus sessions, image prompts, and file analysis. Tell me your current goal.';

  return {
    id: newId('chat'),
    reply,
    actions
  };
}

module.exports = {
  orchestrateChat
};
